/* COPYRIGHT (C) GUPTA CORPORATION 1984-1997 */
/*
INTERFACE TO
  SQL SRV EXTENDED INFORMATION
*/
/*
REVISION HISTORY
  04/02/93 GTI release 5.2.0
  02/07/95 GTI release 6.0.0
  04/12/95 GTI release 6.0.1
  08/02/95 GTI release 6.1.0
  12/20/95 GTI release 6.1.1
  11/14/96 GTI release 6.5.0
  10/20/97 GTI release 7.0.0
  09/15/98 GTI release 7.5.0
  11/10/00 GTI release 7.6.0
  11/08/01 RWS release 8.0.0
  10/22/02 GTI release 8.1.0
  12/20/02 GTI release 8.5.0
DESCRIPTION
  This file contains structure	definitions  and  defined  constants  used  to
  interface with a SQLBASE SERVER and return extended GSI information.
*/

#ifndef GSIEXT
#define GSIEXT

#include "sqlbase.h"

#ifdef __cplusplus
extern "C"
{										/* Assume C declarations for C++ */
#endif /* __cplusplus */

#pragma pack(push, 1)

#ifndef SIZEOF
#define SIZEOF(x) (int)sizeof(x)
#endif

#define   SQLGLCK   0x40				/* lock information */
#define   SQLGOSS   0x80				/* OS stats information */

/* information filter flags */
#define   SQLRPNM   0x0100				/* process number */
#define   SQLRCLN   0x0200				/* client name */
#define   SQLRUSN   0x0400				/* user name */
#define   SQLRDBN   0x0800				/* database name */

#define   SQLXGSI   0x8000				/* extended GSI information flag */

/* extended cursor information */
struct curdefxi
{
	ubyte4 curcst;				/* cost of execution plan */
	ubyte4 curctp;				/* time for prepare */
	ubyte4 curcte;				/* time for execute */
	ubyte4 curctf;				/* time for fetch */
	ubyte2 curcur;				/* internal cursor number */
	ubyte1 curcln[13];			/* client name */
	ubyte1 cursta;				/* cursor status */
	ubyte1 curcts[18];			/* cursor time stamp */
	ubyte1 curflg;				/* cursor flags */
	ubyte1 currsv[1];			/* reserved */
};
typedef struct curdefxi curdefi;
#define CURXSIZ SIZEOF(curdefi)

/* configuration information */
struct cfgdefxi
{
	ubyte4 cfgcmt[60];			/* command type counters */
	ubyte4 cfgcon;				/* total system connects */
	ubyte4 cfgdis;				/* total system disconnects */
	ubyte4 cfgtps;				/* number of transactions */
	ubyte4 cfgelp;				/* number of exclusive locks */
	ubyte4 cfgslp;				/* number of shared locks */
	ubyte4 cfgulp;				/* number of update locks */
	ubyte4 cfgdlk;				/* number of deadlocks */
	ubyte4 cfgsrt;				/* number of sorts */
	ubyte4 cfghjn;				/* number of hashed joins */
	ubyte4 cfgctp;				/* time for prepare */
	ubyte4 cfgcte;				/* time for execute */
	ubyte4 cfgctf;				/* time for fetch */
	ubyte1 cfgsbt[26];			/* time of SQLBase boot */
	ubyte1 cfgpfs[21];			/* platform version string */
	ubyte1 cfgver[20];			/* SQLBase version */
	ubyte1 cfgonl;				/* online/offline */
	ubyte4 cfgszp;				/* Database Page size on server */
};
typedef struct cfgdefxi cfgdefi;
#define CFGXSIZ SIZEOF(cfgdefi)

/* process information */
struct prcdefxi
{
	ubyte4 prcsel;				/* number of selects */
	ubyte4 prcins;				/* number of inserts */
	ubyte4 prcupd;				/* number of updates */
	ubyte4 prcdel;				/* number of deletes */
	ubyte4 prctps;				/* number of transactions */
	ubyte4 prcdlk;				/* number of deadlocks */
	ubyte4 prcelp;				/* number of exclusive locks */
	ubyte4 prcslp;				/* number of shared locks */
	ubyte4 prculp;				/* number of update locks */
	ubyte4 prcast;				/* accumulative system time */
	ubyte4 prcptp;				/* time for prepare */
	ubyte4 prcpte;				/* time for execute */
	ubyte4 prcptf;				/* time for fetch */
	ubyte4 prcmtt;				/* maximum transaction time */
	ubyte1 prcpss[26];			/* status string */
	ubyte1 prccln[13];			/* client name */
	ubyte1 prcsta;				/* status flag */
	ubyte1 prcpts[20];			/* process time stamp */
	ubyte1 prciso;				/* isolation level flags */
	ubyte4 prctmo;				/* number of timeouts */
	ubyte1 prcrsv[27];			/* reserved */
};
typedef struct prcdefxi prcdefi;
#define PRCXSIZ SIZEOF(prcdefi)

/* database information */
struct dbsdefxi
{
	ubyte1 dbspnm[7][9];			/* protocol name */
	ubyte1 dbsshd;				/* shutdown */
	ubyte1 dbslck;				/* locked/unlocked */
	ubyte1 dbsrsv[63];			/* reserved */

};
typedef struct dbsdefxi dbsdefi;
#define DBSXSIZ SIZEOF(dbsdefi)

/* lock information */
struct lckdefx
{
	ubyte1 lckdbs[17];			/* database file name */
	ubyte1 lckpnm;				/* process number */
	ubyte2 lcklpg;				/* low  page */
	ubyte2 lckhpg;				/* high page */
	ubyte4 lckgrp;				/* lock group */
	ubyte1 lckmod;				/* lock mode */
	ubyte1 lckuse;				/* lock use count */
};
typedef struct lckdefx lckdef;
#define LCKSIZ SIZEOF(lckdef)

/* filter structure */
struct fgidefx
{
	ubyte1 fgipnm;				/* process number */
	ubyte1 fgicln[13];			/* client name */
	ubyte1 fgiunb[19];			/* user name buffer */
	ubyte1 fgidbn[17];			/* database name buffer */
};
typedef struct fgidefx fgidef;
#define  FGISIZ SIZEOF(fgidef)


/* OS stats information */
struct ostdefx
{
	ubyte1 ostsar;				/* sample rate */
	ubyte1 ostaws;				/* averaging window size */

	ubyte1 ostcpu;				/* CPU % Utilization */
	ubyte1 ostacp;				/* Average CPU % Utilization */
	ubyte1 ostpac;				/* Peak Average CPU % Utilization */

	ubyte4 ostmpa;				/* Physical memory available */
	ubyte4 ostmvt;				/* Total virtual memory */
	ubyte4 ostmst;				/* Short term memory available */
	ubyte4 ostmlt;				/* Long term memory available */

	ubyte4 ostdpr;				/* disk I/O physical reads */
	ubyte4 ostdpw;				/* disk I/O physical writes */
	ubyte4 ostbpr;				/* disk I/O physical bytes read */
	ubyte4 ostbpw;				/* disk I/O physical bytes write */
	ubyte4 ostdvr;				/* disk I/O virtual  reads */
	ubyte4 ostdvw;				/* disk I/O virtual  writes */
	ubyte4 ostbvr;				/* disk I/O virtual  bytes read */
	ubyte4 ostbvw;				/* disk I/O virtual  bytes write */

	ubyte4 ostnpt;				/* Network I/O packets transmitted */
	ubyte4 ostnpr;				/* Network I/O packets received */
	ubyte4 ostprt;				/* Network I/O packets routed */
	ubyte1 ostrsv[3];			/* reserved */
};

typedef struct ostdefx ostdef;
#define OSTSIZ SIZEOF(ostdef)

#pragma pack(pop)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GSIEXT */

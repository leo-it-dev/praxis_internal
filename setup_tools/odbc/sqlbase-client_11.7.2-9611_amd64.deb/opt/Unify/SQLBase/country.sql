[japan]
#whitespace
\9 \A \D \20
#numeric
0 1 2 3 4 5 6 7 8 9
#secondbyte
\40 \41 \42 \43 \44 \45 \46 \47 \48 \49 \4A \4B \4C \4D \4E \4F
\50 \51 \52 \53 \54 \55 \56 \57 \58 \59 \5A \5B \5C \5D \5E \5F
\60 \61 \62 \63 \64 \65 \66 \67 \68 \69 \6A \6B \6C \6D \6E \6F
\70 \71 \72 \73 \74 \75 \76 \77 \78 \79 \7A \7B \7C \7D \7E 
\80 \81 \82 \83 \84 \85 \86 \87 \88 \89 \8A \8B \8C \8D \8E \8F
\90 \91 \92 \93 \94 \95 \96 \97 \98 \99 \9A \9B \9C \9D \9E \9F
\A0 \A1 \A2 \A3 \A4 \A5 \A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
\B0 \B1 \B2 \B3 \B4 \B5 \B6 \B7 \B8 \B9 \BA \BB \BC \BD \BE \BF
\C0 \C1 \C2 \C3 \C4 \C5 \C6 \C7 \C8 \C9 \CA \CB \CC \CD \CE \CF
\D0 \D1 \D2 \D3 \D4 \D5 \D6 \D7 \D8 \D9 \DA \DB \DC \DD \DE \DF
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC
#alpha
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
a b c d e f g h i j k l m n o p q r s t u v w x y z
#firstbyte
    \81 \82 \83 \84 \85 \86 \87 \88 \89 \8A \8B \8C \8D \8E \8F
\90 \91 \92 \93 \94 \95 \96 \97 \98 \99 \9A \9B \9C \9D \9E \9F
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC
#punctuation
   \A1 \A2 \A3 \A4 \A5
#identifier
       			\A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
\B0 \B1 \B2 \B3 \B4 \B5 \B6 \B7 \B8 \B9 \BA \BB \BC \BD \BE \BF
\C0 \C1 \C2 \C3 \C4 \C5 \C6 \C7 \C8 \C9 \CA \CB \CC \CD \CE \CF
\D0 \D1 \D2 \D3 \D4 \D5 \D6 \D7 \D8 \D9 \DA \DB \DC \DD \DE \DF
[china]
; most popular BIG-5 code
#whitespace
\9 \A \D \20
#numeric
0 1 2 3 4 5 6 7 8 9
#secondbyte
\40 \41 \42 \43 \44 \45 \46 \47 \48 \49 \4A \4B \4C \4D \4E \4F
\50 \51 \52 \53 \54 \55 \56 \57 \58 \59 \5A \5B \5C \5D \5E \5F
\60 \61 \62 \63 \64 \65 \66 \67 \68 \69 \6A \6B \6C \6D \6E \6F
\70 \71 \72 \73 \74 \75 \76 \77 \78 \79 \7A \7B \7C \7D \7E 
    \A1 \A2 \A3 \A4 \A5 \A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
\B0 \B1 \B2 \B3 \B4 \B5 \B6 \B7 \B8 \B9 \BA \BB \BC \BD \BE \BF
\C0 \C1 \C2 \C3 \C4 \C5 \C6 \C7 \C8 \C9 \CA \CB \CC \CD \CE \CF
\D0 \D1 \D2 \D3 \D4 \D5 \D6 \D7 \D8 \D9 \DA \DB \DC \DD \DE \DF
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC \FD \FE
#alpha
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
a b c d e f g h i j k l m n o p q r s t u v w x y z
#firstbyte
    \A1 \A2 \A3 \A4 \A5 \A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
\B0 \B1 \B2 \B3 \B4 \B5 \B6 \B7 \B8 \B9 \BA \BB \BC \BD \BE \BF
\C0 \C1 \C2 \C3 \C4 \C5 \C6 \C7 \C8 \C9 \CA \CB \CC \CD \CE \CF
\D0 \D1 \D2 \D3 \D4 \D5 \D6 \D7 \D8 \D9 \DA \DB \DC \DD \DE \DF
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC \FD \FE
[chinaet]
; ET code
#whitespace
\9 \A \D \20
#numeric
0 1 2 3 4 5 6 7 8 9
#secondbyte
\30 \31 \32 \33 \34 \35 \36 \37 \38 \39 
    \41 \42 \43 \44 \45 \46 \47 \48 \49 \4A \4B \4C \4D \4E \4F
\50 \51 \52 \53 \54 \55 \56 \57 \58 \59 \5A
    \61 \62 \63 \64 \65 \66 \67 \68 \69 \6A \6B \6C \6D \6E \6F
\70 \71 \72 \73 \74 \75 \76 \77 \78 \79 \7A
\80 \81 \82 \83 \84 \85 \86 \87 \88 \89 \8A \8B \8C \8D \8E \8F
\90 \91 \92 \93 \94 \95 \96 \97 \98 \99 \9A \9B \9C \9D \9E \9F
\A0 \A1 \A2 \A3 \A4 \A5 \A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
\B0 \B1 \B2 \B3 \B4 \B5 \B6 \B7 \B8 \B9 \BA \BB \BC \BD \BE \BF
\C0 \C1 \C2 \C3 \C4 \C5 \C6 \C7 \C8 \C9 \CA \CB \CC \CD \CE \CF
\D0 \D1 \D2 \D3 \D4 \D5 \D6 \D7 \D8 \D9 \DA \DB \DC \DD \DE \DF
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC \FD
#alpha
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
a b c d e f g h i j k l m n o p q r s t u v w x y z
#firstbyte
    \81 \82 \83 \84 \85 \86 \87 \88 \89 \8A \8B \8C \8D \8E \8F
\90 \91 \92 \93 \94 \95 \96 \97 \98 \99 \9A \9B \9C \9D \9E \9F
\A0 \A1 \A2 \A3 \A4 \A5 \A6 \A7 \A8 \A9 \AA \AB \AC \AD \AE \AF
                                                    \DD \DE \DF
\E0 \E1 \E2 \E3 \E4 \E5 \E6 \E7 \E8 \E9 \EA \EB \EC \ED \EE \EF
\F0 \F1 \F2 \F3 \F4 \F5 \F6 \F7 \F8 \F9 \FA \FB \FC \FD \FE
[germany]
#whitespace
\9 \A \D \20
#numeric
0 1 2 3 4 5 6 7 8 9
#alpha
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z \8E \99 \9A
a b c d e f g h i j k l m n o p q r s t u v w x y z \84 \94 \81 \E1
#translate
\84 a
\8E A
\94 o
\99 O
\81 u
\9A U
\E1 s
\E1 ss
\84 ae
\8E Ae
\94 oe
\99 Oe
\81 ue
\9A Ue
#lower
\8E \84
\99 \94
\9A \81
#upper
\84 \8E
\94 \99
\81 \9A
[germany]
;same germany code page, different sort collating sequence
#whitespace
\9 \A \D \20
#numeric
0 1 2 3 4 5 6 7 8 9
#alpha
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z \8E \99 \9A
a b c d e f g h i j k l m n o p q r s t u v w x y z \84 \94 \81 \E1
#translate
\84 \61
\8E \41
\94 \6F
\99 \4F
\E1 \73
\81 \75
\9A \55
\E1 ss
#lower
\8E \84
\99 \94
\9A \81
#upper
\84 \8E
\94 \99
\81 \9A
;\63 ch
;\43 CH
;#prefix
[ebcdic]
#translate
\00 \00
\01 \01
\02 \02
\03 \03
\04 \37
\05 \2D
\06 \2E
\07 \2F
\08 \16
\09 \05
\0A \25
\0B \0B
\0C \0C
\0D \0D
\0E \0E
\0F \9F
\10 \10
\11 \11
\12 \12
\13 \13
\14 \B6
\15 \B5
\16 \32
\17 \26
\18 \18
\19 \19
\1A \3F
\1B \27
\1C \1C
\1D \1D
\1E \1E
\1F \1F
\20 \40
\21 \5A
\22 \7F
\23 \7B
\24 \5B
\25 \6C
\26 \50
\27 \7D
\28 \4D
\29 \5D
\2A \5C
\2B \4E
\2C \6B
\2D \60
\2E \4B
\2F \61
\30 \F0
\31 \F1
\32 \F2
\33 \F3
\34 \F4
\35 \F5
\36 \F6
\37 \F7
\38 \F8
\39 \F9
\3A \7A
\3B \5E
\3C \4C
\3D \7E
\3E \6E
\3F \6F
\40 \7C
\41 \C1
\42 \C2
\43 \C3
\44 \C4
\45 \C5
\46 \C6
\47 \C7
\48 \C8
\49 \C9
\4A \D1
\4B \D2
\4C \D3
\4D \D4
\4E \D5
\4F \D6
\50 \D7
\51 \D8
\52 \D9
\53 \E2
\54 \E3
\55 \E4
\56 \E5
\57 \E6
\58 \E7
\59 \E8
\5A \E9
\5B \AD
\5C \E0
\5D \BD
\5E \5F
\5F \6D
\60 \79
\61 \81
\62 \82
\63 \83
\64 \84
\65 \85
\66 \86
\67 \87
\68 \88
\69 \89
\6A \91
\6B \92
\6C \93
\6D \94
\6E \95
\6F \96
\70 \97
\71 \98
\72 \99
\73 \A2
\74 \A3
\75 \A4
\76 \A5
\77 \A6
\78 \A7
\79 \A8
\7A \A9
\7B \C0
\7C \6A
\7D \D0
\7E \A1
\7F \07
\80 \68
\81 \DC
\82 \51
\83 \42
\84 \43
\85 \44
\86 \47
\87 \48
\88 \52
\89 \53
\8A \54
\8B \57
\8C \56
\8D \58
\8E \63
\8F \67
\90 \71
\91 \9C
\92 \9E
\93 \CB
\94 \CC
\95 \CD
\96 \DB
\97 \DD
\98 \DF
\99 \EC
\9A \FC
\9B \B0
\9C \B1
\9D \B2
\9E \3E
\9F \B4
\A0 \45
\A1 \55
\A2 \CE
\A3 \DE
\A4 \49
\A5 \69
\A6 \9A
\A7 \9B
\A8 \AB
\A9 \0F
\AA \BA
\AB \B8
\AC \B7
\AD \AA
\AE \8A
\AF \8B
\B0 \3C
\B1 \3D
\B2 \62
\B3 \4F
\B4 \64
\B5 \65
\B6 \66
\B7 \20
\B8 \21
\B9 \22
\BA \70
\BB \23
\BC \72
\BD \73
\BE \74
\BF \BE
\C0 \76
\C1 \77
\C2 \78
\C3 \80
\C4 \24
\C5 \15
\C6 \8C
\C7 \8D
\C8 \8E
\C9 \41
\CA \06
\CB \17
\CC \28
\CD \29
\CE \9D
\CF \2A
\D0 \2B
\D1 \2C
\D2 \09
\D3 \0A
\D4 \AC
\D5 \4A
\D6 \AE
\D7 \AF
\D8 \1B
\D9 \30
\DA \31
\DB \FA
\DC \1A
\DD \33
\DE \34
\DF \35
\E0 \36
\E1 \59
\E2 \08
\E3 \38
\E4 \BC
\E5 \39
\E6 \A0
\E7 \BF
\E8 \CA
\E9 \3A
\EA \FE
\EB \3B
\EC \04
\ED \CF
\EE \DA
\EF \14
\F0 \E1
\F1 \8F
\F2 \46
\F3 \75
\F4 \FD
\F5 \EB
\F6 \EE
\F7 \ED
\F8 \90
\F9 \EF
\FA \B3
\FB \FB
\FC \B9
\FD \EA
\FE \BB
\FF \FF







